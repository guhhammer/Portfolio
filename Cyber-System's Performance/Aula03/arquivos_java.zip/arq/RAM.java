package Main;

public class RAM extends Memory{

	public RAM(int size) {
		super(size);
	}
	
}
