Execute o arquivo ai.py com um ambiente Python.
Bibliotecas necessárias: colorama
Comando: "python ai.py"
Para selecionar o time da IA, altere a última linha do arquivo ai.py, na chamada CheckersAI.
1 = Vermelho
2 = Azul
