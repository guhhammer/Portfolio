
package árvore;       // NOME: Gustavo Hammerschmidt.

public class node{
        
    int info;
    int alturah;
    node esquerda;
    node direita;

    // Uso: construtor de node.
    public node(int i){
        this.info = i;
        this.alturah = -1;
        this.esquerda = null;
        this.direita = null;
    }   // gemacht.
    
}