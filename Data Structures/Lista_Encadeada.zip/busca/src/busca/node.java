
package busca;      

public class node{
        
    int info;
    node esquerda, direita;
    
    // Uso: construtor de node.
    public node(int i){
        this.info = i;
        this.esquerda = this.direita = null;
    }   // gemacht.
    
}