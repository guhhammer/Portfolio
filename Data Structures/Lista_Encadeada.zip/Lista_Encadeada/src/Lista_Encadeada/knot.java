
package Lista_Encadeada;

public class knot {
    
    int dado;
    knot proximo;
    
    public knot(int n){
        this.dado = n;
        this.proximo = null;
    }
    
}
