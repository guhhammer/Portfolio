




$(document).ready(function(){


	$("#btRetornar").click(function(){

		window.open("../html/telaInicio.html", "_self");

	});

	
	$("#btCriarMensagem").click(function(){

		window.open("../html/criarMensagem.html", "_self");

	});


	$("#btFavoritos").click(function(){

		window.open("../html/favoritos.html", "_self");

	});


	$("#btCaixaDeEntrada").click(function(){

		window.open("../html/caixaDeEntrada.html", "_self");

	});


	$("#btItensEnviados").click(function(){

		window.open("../html/itensEnviados.html", "_self");

	});


	$("#btItensExcluidos").click(function(){

		window.open("../html/ItensExcluidos.html", "_self");

	});


	$("#btLixoEletronico").click(function(){

		window.open("../html/lixoEletronico.html", "_self");

	});


	$("#btRascunhos").click(function(){

		window.open("../html/rascunhos.html", "_self");

	});


	$("#btArquivoMorto").click(function(){

		window.open("../html/arquivoMorto.html", "_self");

	});


});