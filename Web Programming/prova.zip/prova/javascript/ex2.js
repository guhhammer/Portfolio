



$(document).ready(function(){

    $("#gravar").click(function(){

        var flag = false;
        $("#divEX2 input").each(function(){

            if($("#divEX2 input").val() == ""){
                flag = true;
            }

        });

        if(flag == true){
            alert("Todos os campos precisam ser preenchidos.");
        }
        else{
            alert("Todos os dados foram gravados com sucesso.");
        }
        
    });


    $("#limpar").click(function(){

        $("#divEX2 input").each(function(){

            $("#divEX2 input").val("");
            
        });
    });


});