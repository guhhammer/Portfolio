



$(document).ready(function(){


    $("#ex2").click(function(){

        window.open("../html/exercicio2.html");

    });

    $("#ex3").click(function(){

        window.open("../html/exercicio3.html");

    });


});