
public enum Color {
	GREEN,
	YELLOW,
	ORANGE,
	RED
}
