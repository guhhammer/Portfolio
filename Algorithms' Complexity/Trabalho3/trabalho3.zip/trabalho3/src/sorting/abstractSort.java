package sorting;

public abstract class abstractSort {


}
