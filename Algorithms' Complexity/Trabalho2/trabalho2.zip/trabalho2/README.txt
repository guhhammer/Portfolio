


Equipe:	
	Gustavo Hammerschmidt.


Execute o Main.py.