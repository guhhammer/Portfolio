
from flask import Flask, render_template
import html, os
from PIL import Image
from auxiliary_functions import *


app = Flask(__name__, static_url_path='/static')


@app.route('/')
def homepage():

	return render_template('home.html', data={})


@app.route('/login')
def login():

	return render_template('login.html')


@app.route('/category/<string:section>')
def category(section):

	data = [{"name": section}]

	content = content_grabber(section)

	return render_template('category.html', data=data, content=content)


@app.route('/receipe/<section>/<receipe_folder_name>')
def receipe(section, receipe_folder_name):

	data = get_info_from_receipe_2(section, receipe_folder_name)

	data['receipe_name'] = " ".join(receipe_folder_name.split("_")).title()

	data['ing_link'] = "/ingredient/"+section+"/"+receipe_folder_name

	return render_template('receipe.html', data=data, filename=data["receipe_photo"])


@app.route('/ingredient/<section>/<receipe_folder_name>')
def ingredient(section, receipe_folder_name):

	data = get_info_from_receipe_2(section, receipe_folder_name)

	data['receipe_name'] = " ".join(receipe_folder_name.split("_")).title()

	return render_template('ingredient.html', data=data, filename=data["receipe_photo"])


@app.route('/on')
def logged():

	data = {}

	data['response'] = "on"

	return render_template('home.html', data=data)


@app.route("/vip")
def vip():
	
	return render_template('vip.html')


@app.route("/createRecipe")
def create():

	return render_template("createRecipe.html")


if __name__ == "__main__":

	app.run(debug=True)

