import html, os
from PIL import Image


def convert_image_extension(section, folder):

	leaf_path = os.getcwd()+'/static/receipes/'+section+"/"+folder
	if os.access(leaf_path+"/receipe_photo.png", os.F_OK):

		img = Image.open(leaf_path+"/receipe_photo.png")

		img.save(leaf_path+"/receipe_photo.jpg")


def get_info_from_receipe(section, folder):

	info = {}

	path = "/static/receipes/"+section+"/"+folder+"/"	

	for file in ['description.txt', 'how_to_cook.txt', 'list_of_ingredients.txt']:
	
		with open(os.getcwd()+path+file, 'r', encoding='utf-8') as f:
		
			info[file.split(".txt")[0]] = f.readlines()

	convert_image_extension(section, folder)

	info['receipe_photo'] = path+"receipe_photo.jpg"

	info['receipe_photo'] = info['receipe_photo'][7:]

	return info


def get_info_from_receipe_2(section, folder):


	info = get_info_from_receipe(section, folder)


	if len(info['description']) > 0:

		info['description'] = str(info['description'])[2:-2]

	else:

		info['description'] = "nothing yet!"
	

	if len(info['how_to_cook']) > 0:

		info['how_to_cook'] = str(info['how_to_cook'])[2:-2]

	else:

		info['how_to_cook'] = "nothing yet!"	
	

	if len(info['list_of_ingredients']) > 0:

		info['list_of_ingredients'] = str(info['list_of_ingredients'])[2:-2]

	else:

		info['list_of_ingredients'] = "nothing yet!"


	return info


def content_grabber(section):

	fullpath = os.getcwd()+"/static/receipes/"+section

	dirs = os.listdir(fullpath)

	content = []

	for folder in dirs:

		_content = {}

		if os.path.isdir(fullpath+"/"+folder):

			for file in ['description', 'how_to_cook', 'list_of_ingredients']:
				
				with open(fullpath+"/"+folder+"/"+file+".txt", 'r', encoding='utf-8') as f:

					_content[file] = f.readlines()

			_fullpath = "/".join(fullpath.split("\\"))

			_content['receipe_photo'] = _fullpath+"/"+folder+"/receipe_photo.jpg"

			_content['receipe_name'] = " ".join(folder.split("_")).title()

			_content['folder_name'] = folder

			_content['section'] = section

			_content['description'] = str(_content['description'])[2:-2]

			content.append(_content)

	return content
