

sudo apt-install python

pip install Flask
pip install Pillow
