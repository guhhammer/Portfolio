
$(document).ready(function(){


	$("#login_block").append(content_switch(false));


})
