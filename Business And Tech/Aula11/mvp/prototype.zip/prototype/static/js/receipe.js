
$(document).ready(function(){


	function decode_txt_to_html(arr){

		arr = arr.split("\&lt;p\&gt;").join("<p>");
		
		arr = arr.split("\&lt;/p\&gt;").join("</p>");

		arr = arr.split("\&lt;b\&gt;").join("<b>");

		arr = arr.split("\&lt;/b\&gt;").join("</b>");

		return arr;

	}


	$("#how_to_content").append(decode_txt_to_html(js_how_to_content));


	$("#list_content").append(decode_txt_to_html(js_list_content));


})

