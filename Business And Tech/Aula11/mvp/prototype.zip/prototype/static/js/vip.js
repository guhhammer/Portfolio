
$(document).ready(function(){


	var back = false;


	$("#b_register").click(function(){

		if (back) {

			window.location.href = '/on';

		}


		$("#ok_stat").html("You are now VIP!");
		$("#b_register").html("Back to Menu");

		back = true;

	});



})
