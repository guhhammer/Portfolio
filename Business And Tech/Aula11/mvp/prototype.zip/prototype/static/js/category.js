
$(document).ready(function(){


	var scripts = document.getElementsByTagName("script"),
    src = scripts[scripts.length-1].src;
		
	path_arr = src.split("/");

	path_arr.pop();
	path_arr.pop();


	$("#category_name").append(category);

	var coverpage_path = path_arr.join("\\")+"\\receipes\\"+category+"\\coverpage.jpg";
    
	$("#cat_header").append("<img id=\"coverpage\" class=\"\" onContextMenu=\"return false;\" src=\""+coverpage_path+"\">");


	console.log(content_arr.length);
	console.log(content_arr);

	function wrap_content(){

		if (content_arr.length === 0){

			return "<p id='empty'> No receipes were added yet! </p>";
		
		}

		/*
	
			'description': '{{item.description}}',
			'how_to_cook': '{{item.how_to_cook}}', 
			'list_of_ingredients': '{{item.list_of_ingredients}}',
			'receipe_photo': '{{item.receipe_photo}}',
			'recipe_name': '{{item.receipe_name}}',
			'folder_name': '{{item.folder_name}}',
			'section': '{{item.section}}'

		*/

		var divs = "";
		for (var i = 0; i < content_arr.length; i++) {
			
			divs += "<div onclick=\"window.location.href='/receipe/"+content_arr[i]['section']+"/"+content_arr[i]['folder_name']+"';\">";

			divs += 	"<img id=\"recipe_photo\" onContextMenu=\"return false;\" src=\""+path_arr.join("\\")+"\\receipes\\"+
																content_arr[i]['section']+"\\"+
																content_arr[i]['folder_name']+"\\receipe_photo.jpg\">";

			divs += 	"<p id=\"recipe_name\"> "+content_arr[i]['recipe_name']+" </p>";

			divs += 	"<p id='recipe_description'> "+content_arr[i]['description']+" </p>";

			divs += "</div>";

			if (i < content_arr.length-1){

				divs += "<hr/>";
					
			}
			
		}

		return divs;

	};

	var recommendations = wrap_content();

	$("#recommend").append(recommendations);


})