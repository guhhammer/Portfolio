
$(document).ready(function(){



	$("#log_in_button").click(function(){

		if (_vip){

			window.location.href='/vip';

		} else {

			window.location.href='/login';
		
		}

	});



})
