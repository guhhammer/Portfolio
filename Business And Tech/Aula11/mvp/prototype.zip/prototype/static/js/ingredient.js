
$(document).ready(function(){


	function decode_txt_to_html(arr){

		arr = arr.split("\&lt;p\&gt;").join("<p>");
		
		arr = arr.split("\&lt;/p\&gt;").join("</p>");

		arr = arr.split("\&lt;b\&gt;").join("<b>");

		arr = arr.split("\&lt;/b\&gt;").join("</b>");

		return arr;

	} // https://developer.mozilla.org/pt-BR/docs/Web/HTML/Element/input/date


	function array_of_ingredients(str_){

		var ings = str_.split("</p><p>");

		for(var i = 0; i < ings.length; i++){

			if (ings[i].includes("</p>")){

				ings[i] = ings[i].replace("</p>", "");

			}

			if (ings[i].includes("<p>")){

				ings[i] = ings[i].replace("<p>", "");

			}			

		}

		return ings;

	}


	var many_ings = 0;
	var _lines = {};


	function block_insert(){
	
		_lines = array_of_ingredients(decode_txt_to_html(_list));

		many_ings = _lines.length;

		for(var i = 0; i < _lines.length; i++){

			var _num = i+1;
			var _cont = "<div id=\"div_of_ing"+_num+"\">";

			_cont +=	"<input type=\"checkbox\" id=\"ing"+_num+"\">";
			_cont += 	"<label id=\"lab_ing"+_num+"\" for=\"ing"+_num+"\"> "+_lines[i]+" </label>";
			_cont += 	"<input type=\"date\" id=\"date_for_ing"+_num+"\" min=\""+_today+"\" value=\""+_today+"\">";

			_cont += 	"</div>";
			
			$("#bl_list").append(_cont);

		}			

	}


	function out(){

		_lines = array_of_ingredients(decode_txt_to_html(_list));

		many_ings = _lines.length;

		for(var i = 0; i < many_ings; i++){
				
			if ($("#ing"+ (i+1) +":checked").val() == undefined){ continue; }

			return false;

		}

		return true;

	}


	function receipt_insert(){

		var _cont = "<p id=\"receipt_header\"> "+_name+" </p>";
		var total = 0, _t = 0, _date_ = "";

		for(var i = 0; i < many_ings; i++){
				

			if ($("#ing"+ (i+1) +":checked").val() == undefined){

				continue;
			
			}

			_date_ = $("#date_for_ing"+(i+1)).val().toString().split("-");
			_date_ = _date_[2]+"/"+_date_[1]+"/"+_date_[0];

			_t = Math.floor(Math.random() * 100);
			_cont += "<div id=\"push_div_"+(i+1)+"\"class=\"\">";
			_cont += "<p class=\"pay_ing"+(i+1)+"\"> "+_lines[i] +" </p>";
			_cont += "<p class=\"push_dash\"> -- </p>";
			_cont += "<p class=\"push_date\"> "+_date_+" </p>";
			_cont += "<p class=\"push_dash\"> -- </p>";
			_cont += "<label for=\"pay_ing"+(i+1)+"\" class=\"price_ing"+(i+1)+" push_price\"> $"+ _t +".00 </label>";
			_cont += "</div>";
			total += _t;

		}

		_cont += "<div id=\"tot_div\"> <p class=\"tot_id\"> Total: </p> <label for=\"tot_id\" class=\"push_price\"> $ "+total+".00 </label> </div>";
		_cont += "<div id=\"message_\"> </div>";
		_cont += "<button id=\"b_confirm\"> Confirm Order </button>";

		return _cont;

	}


	var bt_confirmed_check = false;


	function confirmed_ings(){

		for (var i = 0; i < many_ings; i++){

			$("#push_div_"+(i+1)).addClass("lightGreen");

		}

		bt_confirmed_check = true;

	}


	$("#bl_name").append(" / "+_name);

	block_insert();


	var context_switch = false;
	var twist_context = true;
	var return_to_main = false;

	$("#bl_buy").click(function(){

		if(out()){	return;	}

		$("#side_check").removeClass("hide_scheck");
		$("#side_check").addClass("show_scheck");

		$("div").addClass("blur_back");

		$("#side_check").removeClass("blur_back");

		$("#side_check").empty();
		$("#side_check").append(receipt_insert());

		context_switch = true;
		twist_context = false;

		$("#b_confirm").click(function(){
			
			if(return_to_main){

				window.location.href = "/";

			}

			confirmed_ings();
			
			if (bt_confirmed_check){

				$("#message_").html("Order completed!");

				$("#b_confirm").html("Return to Main page");

				return_to_main = true;

			}

			context_switch = true;
			twist_context = false;

		});

	});


	$(document).on("click", function(){

		if (context_switch && twist_context){

			$("div").removeClass("blur_back");

			$("#side_check").removeClass("show_scheck");
			$("#side_check").addClass("hide_scheck");

			context_switch = false;
		}

		twist_context = true;

	});


})