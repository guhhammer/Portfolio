
$(document).ready(function(){


	var scripts = document.getElementsByTagName("script"),
    src = scripts[scripts.length-1].src;
		
	path_arr = src.split("/");

	path_arr.pop();
	path_arr.pop();

	var plus_ = path_arr.join("\\")+"\\photos\\plus.png";
	var count_ing = 1;

	$(".memo_addy").click(function(){

		var _cont = "<div class=\"pushed\">";
		
		_cont +=		"<p class=\"push_ingredient\"> Ingredient "+(count_ing+1)+": </p>";
		_cont +=		"<label for=\"push_ingredient\"> <input type=\"text\" id=\"ing"+(count_ing+1)+"\"> </label>";

		_cont += "</div>";

		$("#ing_list").append(_cont);

		count_ing += 1;

	});


	$(".drop-area").on('dragenter', function (e){
	
		e.preventDefault();
	
		$(this).css('background', '#BBD5B8');
	
	});

	$(".drop-area").on('dragover', function (e){
	
		e.preventDefault();
	
	});

	$(".drop-area").on('drop', function (e){
	
		$(this).css('background', '#D8F9D3');
	
		e.preventDefault();
		
		var image = e.originalEvent.dataTransfer.files;
		
		createFormData(image);

	});


	function createFormData(image) {

		var formImage = new FormData();
		formImage.append('userImage', image[0]);

	}


	$(".fin").click(function(){

		window.location.href = "/";

	});


})
