import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;

/*
    Passos para implementação
        - Defina qual chave, valor voce irá gerar no Map e Reduce
        - Defina os tipos no mapper (Text, IntWritable, DoubleWritable, FloatWritable)
            - Formato do extends <Object, Text, TIPO_CHAVE, TIPO_VALOR>
        - Defina os tipos no reducer (Text, IntWritable, DoubleWritable, FloatWritable)
            - Formato do extends <TIPO_CHAVE, TIPO_VALOR, TIPO_CHAVE_SAIDA, TIPO_VALOR_SAIDA>
        - Defina os tipos no Main
        - Implemente as funções =)
 */

public class Pratica11 {

    public static class MapperImplementacao11 extends Mapper<Object, Text, Text, FloatWritable>{

        public void map(Object chave, Text valor, Context context) throws IOException, InterruptedException {

            String[] cp = valor.toString().split(";");
            if(cp[0].trim().contains("Brazil")){
                try{
                    float p = Float.parseFloat(cp[6]);
                    context.write(new Text("<"+cp[0]+", "+cp[4]+", "+cp[1]+">"), new FloatWritable(p));

                }catch (Exception e){ e.getSuppressed(); }
            }

        }

    }

    public static class ReducerImplementacao11 extends Reducer<Text, FloatWritable, Text, FloatWritable> {
        public void reduce(Text chave, Iterable<FloatWritable> valores, Context context) throws IOException, InterruptedException {

            float avg = 0.0f; int qntd = 0;
            for(FloatWritable v: valores){ avg += v.get(); qntd++; }
            context.write(chave, new FloatWritable(avg/qntd));

        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        String arquivoEntrada = "/home/dados/operacoes_comerciais/base.csv";
        String arquivoSaida = System.getProperty("user.home") + "/Desktop/" + Pratica11.class.getSimpleName();
        if(args.length == 2){
            arquivoEntrada = args[0];
            arquivoSaida = args[1];
        }
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, String.valueOf(Pratica11.class.getSimpleName()));

        job.setJarByClass(Pratica11.class);
        job.setMapperClass(MapperImplementacao11.class);
        job.setReducerClass(ReducerImplementacao11.class);
        //Defina a classe da chave (Text, IntWritable, DoubleWritable, FloatWritable)
        job.setOutputKeyClass(Text.class);
        //Defina a classe do valor (Text, IntWritable, DoubleWritable, FloatWritable)
        job.setOutputValueClass(FloatWritable.class);

        FileInputFormat.addInputPath(job, new Path(arquivoEntrada));
        FileOutputFormat.setOutputPath(job, new Path(arquivoSaida));

        job.waitForCompletion(true);
    }

}
