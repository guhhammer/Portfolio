curl -X POST -H "Accept: application/json" -H "Content-Type: application/json" http://localhost:5000/ -d '{"image": "cat_img.jpg"}'
