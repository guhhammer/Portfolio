
print("\n\n\t\tServer Address: 127.0.0.1\n\n\t\tPort Number: 5000\n\n")
