python server_info.py && python loader.py

