<<<<<<< HEAD
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;



// I've imported InputStreamReader first.
=======
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
>>>>>>> origin/scenarioB_branch

// I've imported IOException first.


public class GameController {
	
	final int SafeLandingVelocity = 5;
	
	SpaceCraft craft;
	
	public GameController(){
		craft = new SpaceCraft();
		craft.init();
	}
	
	public SpaceCraft getSpaceCraft(){
		return this.craft;
	}
	
	public void run(){
	    //Send welcome message
	    //System.out.println("#Welcome to Lunar Lander");
	    
	    System.out.print("\n");
	    System.out.print("Welcome to my Lunar Lander app");
	    System.out.print("\n");
	
	    
<<<<<<< HEAD
	    System.out.print("\n");
	    System.out.print("Welcome to my Lunar Lander app");
	    System.out.print("\n");
	
            // I've changed the introduction message;
=======
            System.out.println("This is Lunar Lander");    
	    // I've changed the title displayed.
>>>>>>> origin/scenarioB_branch

	    try{
	      //Begin reading from System input
	      BufferedReader inputReader =
	      new BufferedReader(new InputStreamReader(System.in));
	      //Set initial burn rate to 0
	      int burnRate = 0;
	      do{
	        //Prompt user for burn rate and read user response
	        System.out.println("#Enter burn rate or <0 to quit:");
	        try{
	          String burnRateString = inputReader.readLine();
	          burnRate = Integer.parseInt(burnRateString);
	        } catch(NumberFormatException nfe){
		          System.out.println("#Invalid burn rate.");
		          continue;
		    }
	        if (burnRate >=0){
		        craft.setBurnRate(burnRate);
		        //Calculate new status
		        try {
			        craft.calcNewValues();	        	
		        } catch (Exception e){
		        	System.out.println(e.getMessage());
		        	continue;
		        }
		        //Display new status
		        craft.displayValues();
		        //Check if game is over
		        if (checkGameResult()>0){
		        	break;
		        }	        	        	
	        }
	      }
	      while(burnRate >= 0);
	      inputReader.close();
	    } catch(IOException ioe){
	      ioe.printStackTrace();
	    }
		
	}
	
	public int checkGameResult(){
        if(craft.getAltitude() == 0){
        	System.out.println("#Game is over.");
        	if(craft.getVelocity() <= SafeLandingVelocity){
        		System.out.println("#You have landed safely.");
        		return 1;	
        	} else{
        		System.out.println("#You have crashed.");
        		return 2;
        	}
        } else {
        	return 0;
        }
	}

}
