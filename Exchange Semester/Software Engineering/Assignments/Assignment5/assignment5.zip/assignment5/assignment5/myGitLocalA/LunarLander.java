
public class LunarLander {
	
	public static void main (String[] args){
		GameController gc = new GameController();
		gc.run();
	}
	
}
