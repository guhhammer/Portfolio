This project was made on PyCharm. The folder above is the project in the pycharm and how it was structured.
